#version 330
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in vec4 vertexColor;
flat in vec4 wdControl;
out vec4 fragColor;
void main() {
    if(wdControl.r>0.99) {
        if(any(notEqual(ivec2(gl_FragCoord.xy),ivec2(0)))) discard;
        fragColor=vec4(wdControl.rgb,1.0);
        return;
    }
    vec4 c=texture(Sampler0,texCoord0)*vertexColor*ColorModulator;
    if(c.a<0.1) discard;
    fragColor=apply_fog(c,sphericalVertexDistance,cylindricalVertexDistance,
        FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);
}
