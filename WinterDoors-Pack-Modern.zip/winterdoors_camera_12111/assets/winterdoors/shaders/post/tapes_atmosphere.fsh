#version 330
#moj_import <minecraft:globals.glsl>
uniform sampler2D InSampler;
uniform sampler2D DepthSampler;
uniform sampler2D ParticlesSampler;
in vec2 texCoord;
out vec4 fragColor;

float wdNoise(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
vec3 wdGrade(vec3 color){
    float grey=dot(color,vec3(0.299,0.587,0.114));
    vec3 muted=mix(color,vec3(grey),0.35);
    muted=mix(muted,floor(muted*32.0)/32.0,0.4)*vec3(1.03,1.0,0.97);
    return pow(max(muted,vec3(0.0)),vec3(0.9));
}
vec4 wdAtmosphere(vec2 coordinate,float motion){
    float seconds=GameTime*1200.0,clock=seconds*6.2831853;
    vec2 uv=coordinate;
    float band=0.0;
    if(motion>0.5){
        vec2 centered=uv*2.0-1.0;
        uv=(centered*(1.0+0.06*dot(centered,centered)))*0.5+0.5;
        float bandDistance=abs(fract(uv.y-fract(seconds*0.004)+0.5)-0.5);
        band=1.0-smoothstep(0.0,0.07,bandDistance);
        uv.x+=band*(wdNoise(vec2(floor(uv.y*140.0),floor(seconds)))-0.5)*0.002;
        if(any(lessThan(uv,vec2(0.0)))||any(greaterThan(uv,vec2(1.0))))return vec4(0,0,0,1);
        uv.x+=wdNoise(vec2(clock*0.00001,float(int(uv.y*100.0))*0.01))*0.0016;
    }
    uv=clamp(uv,vec2(0.001),vec2(0.999));
    vec3 color=texture(InSampler,uv).rgb;
    if(motion>0.5){
        float radius=smoothstep(0.9985,0.9999,texture(DepthSampler,uv).r)*0.004;
        if(radius>=0.0001){
            vec3 blurred=vec3(0);
            for(int i=0;i<8;i++){
                float angle=float(i)*0.7853981625;
                blurred+=texture(InSampler,clamp(uv+vec2(cos(angle),sin(angle))*radius,vec2(0.001),vec2(0.999))).rgb;
            }
            color=mix(color,blurred/8.0,0.7);
        }
    }
    color=wdGrade(color);
    if(motion>0.5){
        vec2 direction=coordinate-0.5;
        vec2 offset=direction*(0.018*(0.35+dot(direction,direction)*1.4))*0.02+vec2(0.0009,0);
        color.r=wdGrade(texture(InSampler,clamp(uv+offset,vec2(0.001),vec2(0.999))).rgb).r;
        color.b=wdGrade(texture(InSampler,clamp(uv-offset,vec2(0.001),vec2(0.999))).rgb).b;
        float line=sin((uv.y+seconds*0.0002)*600.0)*0.5+0.5;
        color*=mix(1.0,0.92,line*0.10);
        color+=vec3((wdNoise(uv+vec2(clock*0.1))-0.5)*0.035);
        color*=1.0+0.035*(wdNoise(vec2(floor(seconds*2.0),7.3))-0.5);
        color=mix(color,vec3(dot(color,vec3(0.299,0.587,0.114))),band*0.08);
        color*=0.82+0.18*(1.0-smoothstep(0.6,1.4,length((coordinate-0.5)*2.0)));
    }
    return vec4(clamp(color,vec3(0),vec3(1)),1.0);
}

void main(){
    vec4 marker=texelFetch(ParticlesSampler,ivec2(0),0);
    bool valid=abs(marker.r*255.0-254.0)<0.5 && marker.g*255.0>237.5 && marker.g*255.0<253.5;
    int flags=valid?int(marker.b*255.0+0.5):0;
    if((flags&192)==0){fragColor=texture(InSampler,texCoord);return;}
    fragColor=wdAtmosphere(texCoord,(flags&64)!=0?1.0:0.0);
}
