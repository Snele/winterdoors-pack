#version 330
#moj_import <minecraft:globals.glsl>
uniform sampler2D MainSampler;
uniform sampler2D MainDepthSampler;
uniform sampler2D TranslucentSampler;
uniform sampler2D TranslucentDepthSampler;
uniform sampler2D ItemEntitySampler;
uniform sampler2D ItemEntityDepthSampler;
uniform sampler2D ParticlesSampler;
uniform sampler2D ParticlesDepthSampler;
uniform sampler2D CloudsSampler;
uniform sampler2D CloudsDepthSampler;
uniform sampler2D WeatherSampler;
uniform sampler2D WeatherDepthSampler;
in vec2 texCoord;
out vec4 fragColor;
vec4 layers[6];
float depths[6];
int count=0;
void insertLayer(vec4 color,float depth) {
    if(color.a==0.0) return;
    int i=count++;
    while(i>0 && depths[i-1]<depth) {layers[i]=layers[i-1];depths[i]=depths[i-1];i--;}
    layers[i]=color;depths[i]=depth;
}
// Sine/dot hash constants, interpolation seeds, periods and amplitudes match
// the reference's heartbeat/alarm/gaze UV mechanism; compositing is standalone.
vec2 noisePair(vec2 p) {
    return fract(sin(vec2(dot(p,vec2(127.1,311.7)),dot(p,vec2(269.5,183.3))))*43758.5453123);
}
vec2 shake(float position,float seed) {
    return mix(noisePair(vec2(floor(position),seed)),noisePair(vec2(floor(position)+1.0,seed)),smoothstep(0.0,1.0,fract(position)))-0.5;
}
float heart(float ticks) {
    float f=fract(ticks/22.0),a=(f-0.16)/0.055,b=(f-0.42)/0.075;
    return clamp(exp(-a*a)+0.6*exp(-b*b),0.0,1.0);
}
void main() {
    vec4 marker=texelFetch(ParticlesSampler,ivec2(0),0);
    bool valid=abs(marker.r*255.0-254.0)<0.5 && marker.g*255.0>237.5 && marker.g*255.0<253.5;
    int mask=valid ? int(marker.b*255.0+0.5) : 0;
    float gaze=valid ? clamp((253.0-marker.g*255.0)/15.0,0.0,1.0) : 0.0;
    bool heartbeat=(mask&2)!=0 || (mask&16)!=0;
    bool alarm=(mask&8)!=0;
    float ticks=GameTime*24000.0,seconds=GameTime*1200.0;
    float beat=heartbeat ? heart(ticks) : 0.0;
    float pulse=0.0;
    vec2 uv=texCoord;
    if(heartbeat) {
        float amplitude=(0.0085+0.0185*beat)*smoothstep(0.08,0.55,length(texCoord-0.5));
        uv+=amplitude*vec2(sin(texCoord.y*21.0+ticks*0.51)+0.5*sin(texCoord.y*8.0-ticks*0.27),
                          sin(texCoord.x*17.0+ticks*0.43)+0.5*sin(texCoord.x*6.0+ticks*0.19));
        uv=0.5+(uv-0.5)*(1.0-0.045*beat);
        uv=clamp(uv+shake(ticks*0.5+beat*10.0,7.3)*0.0065*beat,vec2(0.001),vec2(0.999));
    }
    if(alarm) {
        float phase=fract(seconds*1.1);
        pulse=smoothstep(0.0,0.06,phase)*exp(-3.5*phase);
        float aspect=float(textureSize(MainSampler,0).x)/float(textureSize(MainSampler,0).y);
        vec2 center=(uv-0.5)*vec2(aspect,1.0);
        float angle=0.045*(sin(seconds*0.30*6.2831853)+1.2*length(center)*sin(seconds*0.30*6.2831853*0.63+1.7));
        center=vec2(center.x*cos(angle)-center.y*sin(angle),center.x*sin(angle)+center.y*cos(angle));
        center*=1.0+0.012*sin(seconds*2.1);
        uv=clamp(0.5+center/vec2(aspect,1.0)+shake(seconds*11.0,3.7)*0.0045*(0.5+0.5*pulse),vec2(0.001),vec2(0.999));
    }
    if(gaze>0.001) uv=clamp(uv+shake(seconds*14.0,11.3)*0.0035*gaze,vec2(0.001),vec2(0.999));
    insertLayer(vec4(texture(MainSampler,uv).rgb,1.0),texture(MainDepthSampler,uv).r);
    insertLayer(texture(TranslucentSampler,uv),texture(TranslucentDepthSampler,uv).r);
    insertLayer(texture(ItemEntitySampler,uv),texture(ItemEntityDepthSampler,uv).r);
    vec4 particles=texture(ParticlesSampler,uv);
    bool controlPixel=abs(particles.r*255.0-254.0)<0.5 && particles.g*255.0>237.5 && particles.g*255.0<253.5;
    if(!controlPixel) insertLayer(particles,texture(ParticlesDepthSampler,uv).r);
    insertLayer(texture(CloudsSampler,uv),texture(CloudsDepthSampler,uv).r);
    insertLayer(texture(WeatherSampler,uv),texture(WeatherDepthSampler,uv).r);
    vec3 color=layers[0].rgb;
    for(int i=1;i<count;i++) color=color*(1.0-layers[i].a)+layers[i].rgb;
    // Gaze vignette and alarm tint use the original functional parameters.
    // Extra VHS, rain, SSAO and global opacity changes are intentionally absent.
    if(alarm) {
        vec3 red=vec3(1.0,0.10,0.06);
        color=mix(color,red*(0.30+0.90*dot(color,vec3(0.299,0.587,0.114))),0.20+0.35*pulse)+red*0.05*pulse;
    }
    if(gaze>0.001) {
        vec2 edge=abs(texCoord-0.5)*2.0;
        float distance=max(max(edge.x,edge.y),length(edge)*0.7071);
        float reach=0.60*gaze*(1.0+0.06*sin(seconds*3.3));
        color*=1.0-pow(clamp(smoothstep(1.0-reach,1.0,distance),0.0,1.0),2.0)*gaze;
    }
    fragColor=vec4(color,1.0);
}
