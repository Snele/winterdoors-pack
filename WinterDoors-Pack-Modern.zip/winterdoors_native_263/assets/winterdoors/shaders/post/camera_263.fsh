#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
uniform sampler2D InSampler;
layout(std140) uniform CameraConfig {float Heartbeat;float Alarm;float Gaze;};
layout(location=0) in vec2 texCoord;
layout(location=0) out vec4 fragColor;
vec2 noisePair(vec2 p) {
    return fract(sin(vec2(dot(p,vec2(127.1,311.7)),dot(p,vec2(269.5,183.3))))*43758.5453123);
}
vec2 shake(float position,float seed) {
    return mix(noisePair(vec2(floor(position),seed)),noisePair(vec2(floor(position)+1.0,seed)),smoothstep(0.0,1.0,fract(position)))-0.5;
}
float heart(float ticks) {
    float f=fract(ticks/22.0),a=(f-0.16)/0.055,b=(f-0.42)/0.075;
    return clamp(exp(-a*a)+0.6*exp(-b*b),0.0,1.0);
}

void main(){
    bool heartbeat=Heartbeat>0.5,alarm=Alarm>0.5;
    float gaze=clamp(Gaze,0.0,1.0);
    float ticks=GameTime*24000.0,seconds=GameTime*1200.0;
    float beat=heartbeat ? heart(ticks) : 0.0;
    float pulse=0.0;
    vec2 uv=texCoord;
    if(heartbeat) {
        float amplitude=(0.0085+0.0185*beat)*smoothstep(0.08,0.55,length(texCoord-0.5));
        uv+=amplitude*vec2(sin(texCoord.y*21.0+ticks*0.51)+0.5*sin(texCoord.y*8.0-ticks*0.27),
                          sin(texCoord.x*17.0+ticks*0.43)+0.5*sin(texCoord.x*6.0+ticks*0.19));
        uv=0.5+(uv-0.5)*(1.0-0.045*beat);
        uv=clamp(uv+shake(ticks*0.5+beat*10.0,7.3)*0.0065*beat,vec2(0.001),vec2(0.999));
    }
    if(alarm) {
        float phase=fract(seconds*1.1);
        pulse=smoothstep(0.0,0.06,phase)*exp(-3.5*phase);
        float aspect=float(textureSize(InSampler,0).x)/float(textureSize(InSampler,0).y);
        vec2 center=(uv-0.5)*vec2(aspect,1.0);
        float angle=0.045*(sin(seconds*0.30*6.2831853)+1.2*length(center)*sin(seconds*0.30*6.2831853*0.63+1.7));
        center=vec2(center.x*cos(angle)-center.y*sin(angle),center.x*sin(angle)+center.y*cos(angle));
        center*=1.0+0.012*sin(seconds*2.1);
        uv=clamp(0.5+center/vec2(aspect,1.0)+shake(seconds*11.0,3.7)*0.0045*(0.5+0.5*pulse),vec2(0.001),vec2(0.999));
    }
    if(gaze>0.001) uv=clamp(uv+shake(seconds*14.0,11.3)*0.0035*gaze,vec2(0.001),vec2(0.999));

    vec3 color=texture(InSampler,uv).rgb;
    if(alarm) {
        vec3 red=vec3(1.0,0.10,0.06);
        color=mix(color,red*(0.30+0.90*dot(color,vec3(0.299,0.587,0.114))),0.20+0.35*pulse)+red*0.05*pulse;
    }
    if(gaze>0.001) {
        vec2 edge=abs(texCoord-0.5)*2.0;
        float distance=max(max(edge.x,edge.y),length(edge)*0.7071);
        float reach=0.60*gaze*(1.0+0.06*sin(seconds*3.3));
        color*=1.0-pow(clamp(smoothstep(1.0-reach,1.0,distance),0.0,1.0),2.0)*gaze;
    }

    fragColor=vec4(color,1.0);
}
